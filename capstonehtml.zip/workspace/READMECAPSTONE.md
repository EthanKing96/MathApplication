     ,-----.,--.                  ,--. ,---.   ,--.,------.  ,------.
    '  .--./|  | ,---. ,--.,--. ,-|  || o   \  |  ||  .-.  \ |  .---'
    |  |    |  || .-. ||  ||  |' .-. |`..'  |  |  ||  |  \  :|  `--, 
    '  '--'\|  |' '-' ''  ''  '\ `-' | .'  /   |  ||  '--'  /|  `---.
     `-----'`--' `---'  `----'  `---'  `--'    `--'`-------' `------'
    ----------------------------------------------------------------- 


hello, this is how the site works

'index.html' = home page

'x_dirp.html' = instruction to practice page

'x_dirq.html' = instruction to quiz page

'x_p.html' = practice page

'x_q.html' = quiz page

CSS: Most CSS is on the home.css file, some of the CSS is imbedded in certain pages

All javascript files are in the js folder

Images are stored in the images folder

There is a word document walking through javascript code if needed.